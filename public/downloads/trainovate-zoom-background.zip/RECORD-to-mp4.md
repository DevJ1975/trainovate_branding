# Recording the Animated Zoom Background

Zoom's animated backgrounds accept `.mp4` and `.mov`. The HTML in
this archive is the canonical animation; record it once and reuse
the resulting clip everywhere.

## Recommended specs

  Resolution:  1920 × 1080
  Frame rate:  30 fps (60 fps if your mac is current)
  Duration:    10–15 seconds (Zoom loops automatically)
  Codec:       H.264 (default for QuickTime + Game Bar)

## macOS — QuickTime

1. Open `zoom-background.html` in Safari or Chrome.
2. Press the green ● to enter full-screen.
3. Open **QuickTime Player** → File → **New Screen Recording**.
4. Choose "Record Selected Portion" → drag a 1920×1080 box around
   the screen, OR pick "Record Entire Screen" if your display is
   exactly 1920×1080.
5. Record for ~12 seconds. Stop. Save as `trainovate-zoom-bg.mov`.
6. (Optional) Re-encode to MP4:

   ```bash
   ffmpeg -i trainovate-zoom-bg.mov -c:v libx264 -pix_fmt yuv420p \
          -crf 18 -preset slow trainovate-zoom-bg.mp4
   ```

## Windows — Xbox Game Bar

1. Open `zoom-background.html` in Edge or Chrome at full-screen.
2. Press **Win + G** to open Xbox Game Bar.
3. Capture widget → click the ● record button.
4. Wait ~12 seconds → stop.
5. The clip lives in `Videos\Captures\` as an `.mp4`.

## Upload to Zoom

Zoom desktop client → ⚙ Settings → **Background & Effects** →
**Virtual Backgrounds** → **+** → **Add Video** → select your `.mp4`.

The clip will loop seamlessly because the nucleus animation has no
start/end frame — every electron is mid-orbit at every instant.
