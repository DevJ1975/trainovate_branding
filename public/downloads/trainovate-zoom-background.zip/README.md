# Trainovate.ai Animated Zoom Background

A self-contained HTML file that loops the animated Trainovate.ai
nucleus on a 1920×1080 canvas. Zoom accepts MP4 / MOV files for
animated backgrounds — convert this HTML to MP4 once, then upload
to Zoom.

## What's in this archive

- `zoom-background.html` — the animated background (open in browser to preview)
- `RECORD-to-mp4.md`     — one-time recording instructions
- `LICENSE`              — internal Trainovate.ai brand asset

## Quick path

1. Open `zoom-background.html` in Chrome.
2. Press **F11** to enter full-screen at 1920×1080.
3. Record the screen for 10 seconds:
   - macOS: QuickTime → File → New Screen Recording
   - Windows: Xbox Game Bar (Win+G) → Capture
4. Upload the resulting `.mp4` to Zoom:
   - Zoom → Settings → Background & Effects → "+" → Add Video
