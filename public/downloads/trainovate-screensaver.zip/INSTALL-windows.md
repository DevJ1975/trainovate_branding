# Install on Windows

Windows doesn't ship a built-in HTML screensaver host. We recommend
**Plash** (open-source, signed) for full-screen rendering of HTML on
idle, paired with Windows' built-in Screen Timeout to control when it
appears. For a true `.scr` integration, see Option B.

---

## Option A — Plash (recommended)

### 1. Install Plash

Get it from the Microsoft Store or from the project page:

  https://sindresorhus.com/plash

### 2. Put the screensaver HTML somewhere stable

Move `screensaver.html` to:

  C:\Users\YOURNAME\AppData\Local\Trainovate\screensaver.html

### 3. Point Plash at it

Open Plash → **Open URL…** → paste:

  file:///C:/Users/YOURNAME/AppData/Local/Trainovate/screensaver.html

### 4. Trigger on idle

Plash → Preferences → enable **Show on idle** (set to 5 minutes).

---

## Option B — Native .scr via InstantStorm

If you need a real `.scr` for a managed Windows fleet, wrap the HTML
with **InstantStorm** (free, Adobe AIR-based):

  https://www.instantstorm.com

1. Open InstantStorm → **New Project** → choose a project folder
2. Add `screensaver.html` as the source
3. Output → set name to `Trainovate.scr`
4. Build → produces `Trainovate.scr`
5. Right-click the `.scr` → **Install**, or place it in
   `C:\Windows\System32\` and select it via Settings →
   Personalization → Lock screen → Screen saver settings.

InstantStorm's output is unsigned. For a fleet roll-out you'll want
to sign it with your organization's code-signing certificate before
distribution.
