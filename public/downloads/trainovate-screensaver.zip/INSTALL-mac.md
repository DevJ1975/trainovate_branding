# Install on macOS

We ship the screensaver as HTML and load it through
**WebViewScreenSaver**, an open-source signed `.saver` host.

## 1. Install WebViewScreenSaver

Visit the project's releases page and download the latest signed
`.saver`:

  https://github.com/liquidx/webviewscreensaver/releases

Double-click `WebViewScreenSaver.saver`. macOS will prompt you to
install it for "this user only" — accept that.

## 2. Put the screensaver HTML somewhere stable

Move `screensaver.html` (in this archive) to a path that won't move:

  ~/Library/Application Support/Trainovate/screensaver.html

```bash
mkdir -p ~/Library/Application\ Support/Trainovate
cp screensaver.html ~/Library/Application\ Support/Trainovate/
```

## 3. Point WebViewScreenSaver at it

System Settings → Screen Saver → choose **WebViewScreenSaver** →
**Screen Saver Options…**

In the "URL" field, paste:

  file:///Users/YOURNAME/Library/Application%20Support/Trainovate/screensaver.html

(Replace `YOURNAME` with your macOS short name.)

Set "Refresh every" to **0** so the page never reloads.

## 4. Test

Click **Test** in the screen saver settings. You should see the
nucleus drifting slowly across a dark background.

## 5. (Optional) Multi-display

WebViewScreenSaver mirrors the same URL to every display. The
screensaver is responsive and centers the mark on whichever screen
it lands on.

## Uninstall

Right-click `WebViewScreenSaver` in System Settings → Screen Saver
and choose **Remove**. Delete the
`~/Library/Application Support/Trainovate/` folder.
