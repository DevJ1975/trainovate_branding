# Trainovate Screensaver

A single self-contained HTML file that displays the animated Trainovate
nucleus. Works on macOS, Windows, and Linux through any FOSS HTML
screensaver host. Drop it in, point the host at it, done.

## What's in this archive

- `screensaver.html`  — the screensaver payload. Open it in a browser
                        to preview. The mark drifts slowly across the
                        screen so it can't burn into a panel.
- `INSTALL-mac.md`    — install steps for macOS via WebViewScreenSaver
- `INSTALL-windows.md`— install steps for Windows via Plash
- `LICENSE`           — internal Trainovate brand asset

## Why HTML and not a .saver / .scr installer?

A real .saver bundle on macOS has to be signed with an Apple Developer
ID and notarized, otherwise Gatekeeper will refuse to load it. Same on
Windows — an unsigned .scr triggers SmartScreen. Shipping unsigned
binaries trains users to click past warnings, which is the opposite
of what a brand should do.

Both host apps below are open source, signed by their authors, and let
you point at any URL or local HTML file. Five-step install on each.
